<?= $this->extends('layout/template'); ?>

<?= $this->section('content'); ?>
<div class="container">

    <div class="row">
        <div class="col">
            <h1>About Me</h1>
            <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Aperiam nemo placeat quas beatae adipisci
                quia corrupti tempore,
                autem aliquam ut eligendi eos reprehenderit vero doloribus laudantium id odio, inventore quam!</p>
        </div>
    </div>
</div>
<?= $this->endSection(); ?>